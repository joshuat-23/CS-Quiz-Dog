public class DogMaker {

  public static void main(String[] args) {
    DogMaker Dog = new DogMaker();
    
  }

  public void setName(String name){

  }

  public int getAge(){
    birthday();
    this.age = age();
  }
  
}
